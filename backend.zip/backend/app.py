from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from core.database import (
registrar_usuario, login_usuario, obter_usuario_por_username, verificar_produtos_disponiveis, 
verificar_kg_disponiveis, tabela_produtos, cadastrar_produto, deletar_produto
)
import os
from dotenv import load_dotenv


app = Flask(__name__)
CORS(app)
load_dotenv()
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY")
jwt = JWTManager(app)

# -------------------------
# Ping-Pong para teste de API
# -------------------------
@app.route('/api/ping', methods=['GET'])
def ping():
    return jsonify({"status": "pong", "message": "API is running!"}), 200

# -------------------------
# Api's de Autenticação
# -------------------------
@app.route('/api/login', methods=['POST'])
def login():
    dados = request.get_json()
    username = dados.get('username')
    password = dados.get('password')

    if not username or not password:
        return jsonify({"msg": "Usuário e senha são obrigatórios"}), 400

    verify = login_usuario(username, password)

    try:
        if verify:
            access_token = create_access_token(identity=username)
            usuario = obter_usuario_por_username(username)
            return jsonify({
                "msg": "sucess",
                "token": access_token,
                "user": usuario
            }), 200
        return jsonify({"msg": "Credenciais inválidas"}), 401
    except Exception as e:
        return jsonify({"msg": "Erro ao processar login", "error": str(e)}), 500

@app.route('/api/register', methods=['POST'])
def register():
    dados = request.get_json()
    nome = dados.get('nome')
    username = dados.get('username')
    password = dados.get('password')
    role = dados.get('role')

    try:
        registrar_usuario(nome, username, password, role)
        return jsonify({"msg": "Usuário registrado com sucesso!"}), 201
    except Exception as e:
        return jsonify({"msg": "Erro ao registrar usuário", "error": str(e)}), 500
    
@app.route('/api/me', methods=['GET'])
@jwt_required()
def me():
    username = get_jwt_identity()
    usuario = obter_usuario_por_username(username)

    if not usuario:
        return jsonify({"msg": "Usuário não encontrado"}), 404

    return jsonify({"user": usuario}), 200

# -------------------------
# Api's do Menu Principal
# -------------------------
@app.route("/api/menu/produtos-disponiveis", methods=['GET'])
@jwt_required()
def produtos_disponiveis():
    try:
        dados = verificar_produtos_disponiveis()
        return jsonify({"status": "sucesso", "dados": dados}), 200
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
@app.route("/api/menu/kg-disponiveis", methods=['GET'])
@jwt_required()
def kg_disponiveis():
    try:
        kg = verificar_kg_disponiveis()
        return jsonify({"status": "sucesso", "kg_disponiveis": kg}), 200
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500


# -------------------------
# Api's Gerenciar Produtos
# -------------------------
@app.route('/api/produtos/metricas', methods=['GET'])
@jwt_required()
def produtos_metricas():         
    try:
        dados = verificar_produtos_disponiveis()
        return jsonify({"disponiveis": dados["disponiveis"], "total": dados["total"], "porcentagem": dados['porcentagem']}), 200
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
@app.route('/api/produtos/tabela', methods=['GET'])
@jwt_required()
def tabela_produtos_completa():
    try:
        dados = tabela_produtos()
        return jsonify({"status": "sucesso", "dados": dados}), 200
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
@app.route('/api/produtos/cadastrar', methods=['POST'])
@jwt_required()
def cadastrar_novo_produto():
    try:
        dados = request.get_json()
        sabor = dados.get('sabor')
        preco_pf = dados.get('preco_pf')
        preco_cnpj = dados.get('preco_cnpj')
        quantidade_kg = dados.get('quantidade_kg')
        disponivel = dados.get('disponivel')

        if not all([sabor, preco_pf, preco_cnpj, quantidade_kg, disponivel is not None]):
            return jsonify({"status": "erro", "mensagem": "Todos os campos são obrigatórios"}), 400

        cadastrar_produto(sabor, preco_pf, preco_cnpj, quantidade_kg, disponivel)
        return jsonify({"status": "sucesso", "mensagem": "Produto cadastrado com sucesso!"}), 201
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
@app.route('/api/produtos/deletar', methods=['DELETE'])
@jwt_required()
def deletar_produtodb():
    try:
        dados = request.get_json()
        sabor = dados.get('sabor')
        print(sabor)
        if not sabor:
            return jsonify({"status": "erro", "mensagem": "Campo 'sabor' é obrigatório"}), 400
        deletar_produto(sabor)
        return jsonify({"status": "sucesso", "mensagem": "Produto deletado com sucesso!"}), 200
    except ValueError as ve:
        return jsonify({"status": "erro", "mensagem": str(ve)}), 404
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500
    
# -------------------------
# Api's em desenvolvimento
# -------------------------
@app.route('/api/menu/faturamento-mensal', methods=['GET'])
@jwt_required()
def faturamento_mensal():
    pass

@app.route('/api/menu/atividade-recente', methods=['GET'])
@jwt_required()
def atividade_recente():
    pass


if __name__ == '__main__':
    app.run(debug=True)